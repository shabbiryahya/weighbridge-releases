# TASK_STATUS.md
> Live sprint tracker. Last updated: 2026-06-13

---

## SPRINT OVERVIEW

| Phase | Description | Status |
|-------|-------------|--------|
| 1 | Electron + React + Vite setup | ✅ Done |
| 2 | SQLite + IPC bridge + Migrations | ✅ Done |
| 3 | Weighing screen + Pending tickets | ✅ Done |
| 4 | Masters screen | ✅ Done |
| 5 | Reports screen | ✅ Done |
| 6 | Ticket printing (Full + Data Only modes) | ✅ Done |
| 7 | Settings + Branding | ✅ Done |
| 8 | Login + PIN + Roles + User management | ✅ Done |
| 9 | Docker + Central server + Nginx | ✅ Done |
| 10 | License System (MongoDB backed) | ✅ Done |
| 11 | Data Migration Tool (MDB import) | ✅ Done |
| 12 | Serial Port (live weight) | ⏳ On client machine |
| 13 | Package as .exe installer | ✅ Done |
| 14 | EOD Email | ⏳ Next |
| 15 | Auto Updater | ⏳ Pending |
| 16 | Diagnostics Screen | ✅ Done |
| 17 | Help Screen + Gujarati FAQ | ✅ Done |
| 18 | License Manager (superadmin UI) | ✅ Done |
| 19 | Plan Enforcement (Basic/Pro/Enterprise) | ✅ Done |

---

## COMPLETED FEATURES DETAIL

### Phase 6 — Ticket Printing ✅
- TicketPrint.jsx — generateTicketHTML() + previewTicket()
- Full ticket mode: 3 copies side by side (ORIGINAL/DUPLICATE/TRIPLICATE)
- Data only mode: prints values at configured positions on pre-printed paper
- printer:getAll IPC — lists Windows printers
- printer:print IPC — prints via hidden BrowserWindow
- settings:getPrint IPC — loads all print+company settings
- Print button in WeighingScreen with Preview button
- Settings → Printing tab with mode, printer, paper, font, field toggles
- Test Print + Preview Sample buttons

### Phase 10 — License System ✅
- License screen on app startup
- Validates against wcddev.duckdns.org/api/license/
- Machine ID binding (SHA256 of hostname+platform)
- Offline grace — allows if server unreachable
- License key + plan stored in SQLite settings
- /api/license/reset endpoint for unbinding machines
- Proper error messages per failure reason

### Phase 11 — Data Migration ✅
- Settings → Import Data tab
- Reads WeightSystem.mdb via mdb-reader package
- Imports: tickets, vehicles, materials, suppliers, receivers
- Preview screen before import (shows counts + sample tickets)
- Sets next ticket number to max+1 after import
- dialog:openFile IPC for file picker

### Phase 13 — Package as .exe ✅
- electron-builder configured in package.json
- NSIS installer with custom icon + license
- Output: dist-build/Weighbridge Management System Setup 1.0.0.exe
- asar packaging with better-sqlite3 unpacked
- vite.config.js: base: './' for production paths
- main.js: app.getAppPath() for production file loading
- Menu.setApplicationMenu(null) — removes default Electron menu

### Phase 16 — Diagnostics ✅
- Settings → Diagnostics tab
- Checks: Database, License, Serial Port, Printer, Internet, Server, System
- Click-to-expand fix instructions per issue
- Overall health banner
- Run Again button

### Phase 17 — Help Screen ✅
- Left nav → Help menu item (all roles)
- FAQ in Gujarati (12 questions)
- FAQ in English (8 questions)
- How To Use (3 workflows with numbered steps)
- Keyboard Shortcuts (no developer hints)
- Support/Contact tab with developer details

### Phase 18 — License Manager ✅
- Settings → Licenses tab (superadmin only)
- Generate new license with auto key (WB-XXXX-XXXX-XXXX)
- Select plan: Basic / Pro / Enterprise
- Optional expiry date
- Copy to clipboard button
- View all licenses table (client, key, plan, status, activated, expires)
- Reset button to unbind machine
- Server: /api/license/reset endpoint

### Phase 19 — Plan Enforcement ✅
- usePlan hook (PlanContext)
- PlanProvider wrapping App
- PlanGate component — shows 🔒 locked screen for restricted features
- Plan stored in SQLite (license_plan) after activation
- Basic: weighing, masters, reports, printing only
- Pro: + migration, EOD email, sync, export, max 5 operators
- Enterprise: + unlimited users, multi weighbridge, priority support
- users:add IPC enforces operator count per plan
- Settings → System → Change License Key + reload on plan change
- Plan badge shown in sidebar

---

## KNOWN ISSUES

1. Serial port simulated — needs real implementation on client machine
2. EOD email not yet built (Phase 14)
3. Auto updater not yet built (Phase 15)
4. Baud rate default — verify it's 2400 in database.js
5. Passwords stored as plain text — need bcrypt before production
6. loadAll in SettingsScreen missing printer load — fixed in latest session

---

## IMMEDIATE NEXT

1. Build Phase 14 — EOD Email
2. Build Phase 15 — Auto Updater
3. Implement serial port on client machine
4. Set up Shree Bhagwati license as Pro plan
