# CLAUDE.md — Weighbridge Management System
> Single source of truth. Keep this updated after every task.
> Last updated: 2026-06-13

---

## PROJECT PURPOSE

A commercial desktop application to manage weigh bridge operations — replacing legacy .NET/Access software. Built to sell to multiple clients, not single-use. First client: Shree Bhagwati Weigh Bridge, Pansora, Dist. Anand, Gujarat.

**Core function**: Vehicle arrives on scale → software reads weight from hardware → saves ticket → prints 3-copy ticket.

---

## BUSINESS REQUIREMENTS

1. Replace Alpha Weighing Consultancy legacy software at Shree Bhagwati
2. Sellable to multiple clients — each installation is isolated
3. Client self-configures everything (zero developer calls for basic config)
4. Works 100% offline — internet only for license, EOD email, updates
5. Owner gets daily email summary (anti-theft, accountability)
6. License system — app locked without valid key
7. Data migration from legacy Access .mdb

---

## TECHNOLOGY STACK

```
Desktop App:
  Electron.js (wrapper)
  React 18 + Vite (UI)
  SQLite via better-sqlite3 (local DB)
  electron-builder (packaging → .exe)
  electron-updater + GitHub Releases (auto-update)
  serialport (hardware weight reading)

Central Server (wcddev.duckdns.org):
  Node.js + Express (API)
  MongoDB via Mongoose (cloud DB)
  Docker + Docker Compose (containerization)
  Nginx (reverse proxy)

Dev Machine: Windows 11, D:\weighbridge-app\
Server: Ubuntu Linux, /home/shabbir/docker/weighbridge/
```

---

## FOLDER STRUCTURE

```
D:\weighbridge-app\
├── src/                        ← Electron main process
│   ├── main.js                 ← Electron app entry + all IPC handlers
│   ├── preload.js              ← Bridge: exposes IPC to React via window.db
│   └── database.js             ← SQLite connection, schema, migrations
├── client/                     ← React app (Vite)
│   └── src/
│       ├── modules/
│       │   ├── weighing/       WeighingScreen.jsx
│       │   ├── masters/        MastersScreen.jsx
│       │   ├── reports/        ReportsScreen.jsx
│       │   ├── settings/       SettingsScreen.jsx, UsersScreen.jsx
│       │   └── auth/           LoginScreen.jsx
│       ├── components/
│       │   ├── AutocompleteInput.jsx
│       │   ├── ChangePasswordModal.jsx
│       │   └── TicketPrint.jsx (partial)
│       ├── hooks/
│       │   └── useAuth.jsx
│       ├── App.jsx
│       └── main.jsx
├── package.json                ← Root (Electron + scripts)
├── SPRINT_PLAN.md
├── USER_MANUAL.md
└── DEVELOPER_DOCS.md

Server: /home/shabbir/docker/weighbridge/
├── docker-compose.yml
├── .env
└── api/
    ├── Dockerfile
    ├── package.json
    └── src/
        ├── index.js
        ├── routes/
        │   ├── license.js
        │   ├── sync.js
        │   └── support.js
        └── middleware/
            └── auth.js
```

---

## DATABASE SCHEMA

### SQLite (local, per client installation)

**settings**
```sql
key TEXT PRIMARY KEY
value TEXT
updated_at DATETIME
```
Default keys: company_name, company_address, company_contact, company_city, company_logo, ticket_next_no (start at 1, or 983 for Shree Bhagwati), ticket_copies (3), ticket_footer, paper_size (80mm), app_theme_color (#e94560), app_title, com_port (COM1), baud_rate (2400), data_bits (8), parity (none), stop_bits (1), print_mode (full), print_copies (3), print_paper (80mm), print_show_supplier, print_show_receiver, print_show_royalty, print_show_transporter, print_show_remarks, print_show_charges, print_show_vehicle_type, charges_type (per_ton default, per_wheel for Shree Bhagwati), charges_rate (0), printer_name, eod_email, eod_enabled

**vehicles**
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
vehicle_no TEXT UNIQUE NOT NULL
owner_name TEXT
vehicle_type TEXT DEFAULT 'Truck'
standard_tare REAL DEFAULT 0       -- auto-fill tare if known
is_active INTEGER DEFAULT 1
created_at DATETIME
```

**materials**
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
name TEXT UNIQUE NOT NULL
rate_per_ton REAL DEFAULT 0
is_active INTEGER DEFAULT 1
created_at DATETIME
```

**suppliers**
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
name TEXT UNIQUE NOT NULL
is_active INTEGER DEFAULT 1
created_at DATETIME
```

**receivers**
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
name TEXT UNIQUE NOT NULL
is_active INTEGER DEFAULT 1
created_at DATETIME
```

**tickets** (main table)
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
ticket_no TEXT UNIQUE NOT NULL
vehicle_no TEXT NOT NULL
vehicle_type TEXT
vehicle_owner TEXT
material_name TEXT
supplier_name TEXT
receiver_name TEXT
gross_weight REAL
gross_date TEXT
gross_time TEXT
tare_weight REAL
tare_date TEXT
tare_time TEXT
net_weight REAL
royalty_no TEXT
transporter TEXT
rate_per_ton REAL DEFAULT 0
charges REAL DEFAULT 0
wheel_count INTEGER DEFAULT 0
remarks TEXT
status TEXT DEFAULT 'pending'      -- pending | complete | printed
is_synced INTEGER DEFAULT 0
created_at DATETIME
updated_at DATETIME
```

**users**
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
username TEXT UNIQUE NOT NULL
password TEXT NOT NULL             -- plain text for now (TODO: hash)
pin TEXT                           -- 4-digit PIN
role TEXT DEFAULT 'operator'       -- operator | admin | superadmin
full_name TEXT
is_active INTEGER DEFAULT 1
last_login DATETIME
created_at DATETIME
```

Default users (seeded on fresh install):
- superadmin / WB-{machine_hash} / no PIN / superadmin
- admin / admin123 / 1111 / admin
- operator / op123 / 2222 / operator

### MongoDB (central server)
Collections: licenses, tickets_sync, support_tickets

---

## IPC HANDLERS (main.js → preload.js → React)

All exposed via `window.db.*`

```
window.db.settings.getAll()
window.db.settings.update(key, value)
window.db.settings.saveLogo(base64)
window.db.settings.getCharges()
window.db.settings.getPrint()        ← verify exists

window.db.vehicles.getAll()
window.db.vehicles.getAllNos()
window.db.vehicles.getByNo(vehicleNo)
window.db.vehicles.autoSave(vehicleNo, vehicleType)
window.db.vehicles.upsert(data)
window.db.vehicles.delete(id)

window.db.materials.getAll()
window.db.materials.upsert(data)
window.db.materials.delete(id)

window.db.suppliers.getAll()
window.db.suppliers.upsert(data)

window.db.receivers.getAll()
window.db.receivers.upsert(data)

window.db.tickets.save(data)         ← inserts or updates
window.db.tickets.getPending()
window.db.tickets.getRecent(limit)
window.db.tickets.getNextNo()

window.db.reports.daily(date)
window.db.reports.monthly(year, month)
window.db.reports.summary(date)
window.db.reports.search(query)
window.db.reports.all(page, limit)

window.db.auth.login(username, password)
window.db.auth.loginPin(pin)
window.db.auth.devLogin(password)
window.db.auth.generateDevPassword()
window.db.auth.changePassword(userId, currentPw, newPw, newPin)
window.db.auth.resetPassword(targetUserId, newPw, newPin)
window.db.auth.getUsers()
window.db.auth.upsertUser(data)
window.db.auth.deleteUser(id)

window.db.printer.getAll()           ← list Windows printers
window.db.printer.print(html, name)  ← verify exists

window.db.app.info()
```

---

## USER ROLES & PERMISSIONS

| Screen / Action | Operator | Admin | Superadmin |
|----------------|----------|-------|------------|
| Weighing | ✅ | ✅ | ✅ |
| Masters | ❌ | ✅ | ✅ |
| Reports | ✅ view | ✅ | ✅ |
| Settings | ❌ | ✅ | ✅ |
| Users | ❌ | ✅ (own team) | ✅ (all) |
| Delete tickets | ❌ | ✅ | ✅ |
| Reset ticket no. | ❌ | ❌ | ✅ |
| Developer tab | ❌ | ❌ | ✅ |
| Change own password | ✅ | ✅ | ✅ |
| Reset others' password | ❌ | ✅ (operators) | ✅ |

---

## AUTHENTICATION LOGIC

### Normal Login
- PIN screen: shows on-screen keypad + accepts physical keyboard
- PIN resolves to highest-privilege matching active user
- Password tab: username + password for admin/operator
- Superadmin NOT available on normal login screen

### Developer Access
- Keyboard shortcut: **Ctrl + Shift + D** anywhere in app
- Opens hidden dev login popup
- Accepts superadmin password only
- Password formula: `SHA256(hostname + 'WBDEV2026SECRET')` → first 8 chars uppercase → `WB-XXXXXXXX`
- Run this anytime to get password for any machine:
  ```bash
  node -e "const c=require('crypto'),o=require('os');console.log('WB-'+c.createHash('sha256').update(o.hostname()+'WBDEV2026SECRET').digest('hex').slice(0,8).toUpperCase())"
  ```
- Password is the same every time on the same machine (deterministic)

---

## WEIGHING WORKFLOW

### Scenario 1 — Known Tare (Most Common)
1. Operator enters vehicle number → tare auto-fills from vehicle master (if saved)
2. Selects material → rate auto-fills → charges formula ready
3. Truck on scale → stable weight detected → click "Capture GROSS"
4. Net auto-calculates, charges auto-calculates
5. Save & Complete → Print

### Scenario 2 — Two Visits
1. Enter vehicle, material → Capture GROSS → Save Pending
2. Ticket appears in Pending list
3. Truck returns empty → operator clicks pending ticket
4. Capture TARE → Net calculated → Save Complete → Print

### Scenario 3 — Multiple Trucks
Each truck has its own pending ticket. Operator works through the pending list.

---

## CHARGES LOGIC

| Type | Formula | Shree Bhagwati |
|------|---------|----------------|
| per_wheel | wheel_count × rate | ✅ ₹10/wheel |
| per_ton | (net_weight / 1000) × rate | Other clients |
| flat | rate (fixed per ticket) | Some clients |
| manual | operator enters manually | Special cases |

Rate auto-filled from material master; operator can override per ticket.

---

## SERVER INFRASTRUCTURE

```
wcddev.duckdns.org
├── /health              → {"status":"ok","mongo":"connected",...}
├── /api/license/        → POST /validate, POST /create, GET /all
├── /api/sync/           → POST /tickets, GET /tickets/:clientId
└── /api/support/        → POST /ticket, GET /tickets, POST /ticket/:id/reply
```

- API container: `wb_api` → port 3003
- MongoDB container: `wb_mongo` → internal only
- Network: `weighbridge_wb_network` (isolated)
- Nginx: `/etc/nginx/sites-available/weighbridge`
- Server dir: `/home/shabbir/docker/weighbridge/`
- Auth for admin routes: `x-dev-key: WB_LICENSE_2026_SECRET` header

### Existing Apps on Same Server (DO NOT DISTURB)
Ports 3001 (multical), 3002 (hijri_sync), 5432 (postgres), 6379 (redis), 8020 (ledgeriq), 9443 (portainer). Container names prefixed differently. All isolated.

---

## HARDWARE INTEGRATION (Shree Bhagwati)

```javascript
// Serial port settings
{
  path: 'COM1',
  baudRate: 2400,
  dataBits: 8,
  stopBits: 1,
  parity: 'none'
}
// Weight stability: same value 3-5 consecutive readings
// Raw data format: "+0023450\r\n" (parse digits only)
```

---

## PRINTING

### Modes
- `data_only`: prints only field values at configured positions (pre-printed paper)
- `full`: prints complete ticket including headers and borders

### Full Ticket Format (B&W, monospace, dot matrix safe)
```
================================
   COMPANY NAME
   Address line 1
   City, Contact
================================
** ORIGINAL **     No: 983
--------------------------------
Date: 09-06-2026   Time: 14:53
Vehicle: GJ01XX1234
Material: Sand             Rs: 100
Supplier: Kalptaru
Receiver: Gujarat Minerals
Royalty:
--------------------------------
GROSS:        31650 Kg
TARE:          8200 Kg
NET:          23450 Kg
================================
Operator Sign: ________________
================================
```

### Three Copies
Single page, 3 columns side by side: ORIGINAL | DUPLICATE | TRIPLICATE  
Print once → tear → distribute.

---

## DATA MIGRATIONS RULE

**NEVER tell client to delete database.**

Every schema change:
1. Add column to `CREATE TABLE` in `initializeTables()` (for fresh installs)
2. Add `ALTER TABLE` to `runMigrations()` (for existing installs)
3. Both steps always together

Current migrations in `runMigrations()`:
- tickets: vehicle_owner, status, wheel_count
- users: last_login, pin, full_name
- vehicles: standard_tare

---

## SPRINT PHASES STATUS

| Phase | Description | Status |
|-------|-------------|--------|
| 1 | Electron + React setup | ✅ Complete |
| 2 | SQLite + Migrations | ✅ Complete |
| 3 | Weighing screen + Pending tickets | ✅ Complete |
| 4 | Masters screen | ✅ Complete |
| 5 | Reports screen | ✅ Complete (export pending) |
| 6 | Ticket printing | ⚠️ Partially built — awaiting paper spec |
| 7 | Settings + Branding | ✅ Complete |
| 8 | Login + User Roles | ✅ Complete |
| 9 | Docker + Central Server | ✅ Complete |
| 10 | License System | ⏳ Pending |
| 11 | Support Ticketing | ⏳ Pending |
| 12 | EOD Email | ⏳ Pending |
| 13 | Auto Updater | ⏳ Pending |
| 14 | Package as .exe | ⏳ Pending |
| 15 | Data Migration Tool | ⏳ Pending |

---

## KNOWN ISSUES

1. **Baud rate default** — verify `src/database.js` default is `2400` not `9600`
2. **Starting ticket no** — must be set to 983 for Shree Bhagwati during onboarding
3. **Charges tab** — verify Settings → Charges tab implementation is complete
4. **Print preload** — verify `window.db.printer.print` and `window.db.settings.getPrint` exist in preload.js
5. **Password hashing** — passwords stored as plain text; should hash with bcrypt before production

---

## DEVELOPMENT GUIDELINES

1. State the user promise before writing any code
2. Check this CLAUDE.md before starting any task
3. Every new DB column → BOTH `initializeTables()` AND `runMigrations()`
4. Every new IPC handler → BOTH `main.js` AND `preload.js`
5. No hardcoded client values — everything configurable in Settings
6. All errors caught and user-friendly message shown; never crash
7. Three patches on same bug = wrong abstraction; stop and redesign
8. Test on Windows 7 64-bit before client delivery
9. Always use `wb_` prefix for Docker containers/networks
10. Never modify other apps' nginx configs or docker-compose files on server

---

## NEXT IMMEDIATE ACTIONS

1. Verify baud rate default = 2400 in database.js
2. Verify preload.js has all handlers (printer.print, settings.getPrint, settings.getCharges)
3. Complete charges tab in SettingsScreen.jsx
4. Implement Phase 10: License System
5. Implement serial port live weight reading (currently simulated)

---

## UPDATE — 2026-06-13

### New Features Added

#### Ticket Printing (Phase 6)
- Two modes: full (blank paper) and data_only (pre-printed paper)
- 3 copies side by side: ORIGINAL | DUPLICATE | TRIPLICATE
- Settings → Printing tab for full configuration
- Preview button (no printer needed for testing)

#### License System (Phase 10)
- Activation screen on first launch
- MongoDB-backed license storage on server
- Machine binding on first activation
- /api/license/reset to unbind machines
- Offline grace when server unreachable
- Plan stored locally in SQLite after activation

#### Data Migration (Phase 11)
- Settings → Import Data (admin/superadmin only)
- Reads WeightSystem.mdb directly
- Preview before import
- Sets next ticket to max+1

#### Package as .exe (Phase 13)
- NSIS installer built with electron-builder
- Custom icon (build/icon.ico)
- vite base: './' required for production
- app.getAppPath() for production file path
- Menu.setApplicationMenu(null) removes default menu

#### Diagnostics (Phase 16)
- Settings → Diagnostics
- Checks all system components
- Click to expand fix instructions

#### Help + Gujarati FAQ (Phase 17)
- Left nav Help item
- Gujarati FAQ for operators
- How-To workflows
- Shortcuts (no developer hints)

#### License Manager (Phase 18)
- Settings → Licenses (superadmin only)
- Generate keys with auto WB-XXXX-XXXX-XXXX format
- View/reset all licenses

#### Plan Enforcement (Phase 19)
- usePlan hook + PlanProvider + PlanGate component
- Basic / Pro / Enterprise plans
- Features locked per plan
- Change License Key in Settings → System
- Plan badge in sidebar

### License Keys Issued
- WB-1898-6A27-7F37 → Shree Bhagwati Weigh Bridge (basic — upgrade to pro)
- WB-DEV-SEBYY-2026 → Developer machine (Sebyy)
- WB-TEST-2026-01 → Test machine

### Server Routes
- POST /api/license/create — auto generates key if not provided
- POST /api/license/validate — validates + binds machine
- POST /api/license/reset — unbinds machine (devKey protected)
- GET /api/license/all — lists all licenses (x-dev-key protected)
