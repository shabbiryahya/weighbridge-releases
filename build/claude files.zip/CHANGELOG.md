# CHANGELOG.md
> Reverse chronological. Add entry after every completed task.

---

## [Unreleased — In Development]

---

## [0.9.0] — 2026-06-11: Server Infrastructure

### Added
- Docker deployment on wcddev.duckdns.org
- Node.js/Express API container (wb_api, port 3003)
- MongoDB container (wb_mongo, internal)
- License validation API (/api/license/)
- Ticket sync API (/api/sync/)
- Support ticket API (/api/support/)
- Nginx reverse proxy for wcddev.duckdns.org
- Health check endpoint

### Fixed
- MongoDB URI with special characters (@, #) — encodeURIComponent fix
- Docker permission for shabbir user
- API port changed from 3001 → 3003 (conflict with multical_api)
- MongoDB connection retry logic (5 retries, 5s delay)

---

## [0.8.0] — 2026-06-10: Login + User Roles

### Added
- LoginScreen.jsx with PIN keypad (on-screen + keyboard)
- Password login tab
- useAuth hook (user state, logout, can() permissions)
- Role-based navigation filtering
- UsersScreen.jsx (create/edit/deactivate users)
- ChangePasswordModal.jsx
- Superadmin hidden login via Ctrl+Shift+D
- Deterministic superadmin password (SHA256 machine hash)
- Auth IPC handlers: login, loginPin, devLogin, generateDevPassword, changePassword, resetPassword
- Nav items restricted by role

### Fixed
- Duplicate user info block in App.jsx sidebar

---

## [0.7.0] — 2026-06-09: Settings + Branding

### Added
- SettingsScreen.jsx with tabs: Company, Branding, Ticket, Charges, Email, Hardware, System, Developer
- Logo upload (base64 stored in settings)
- Theme color picker
- Paper size configuration
- Charges type selector (per_wheel / per_ton / flat / manual)
- Hardware settings (COM port, baud rate, printer name)
- Developer contact tab
- settings:saveLogo and app:info IPC handlers
- Default settings expanded in database.js

---

## [0.6.0] — 2026-06-09: Reports Screen

### Added
- ReportsScreen.jsx
- Daily report (filter by date)
- Monthly report (filter by year/month)
- Summary stats (total tickets, total net, total charges)
- Search tab
- reports:daily, reports:monthly, reports:summary, reports:search, reports:all IPC handlers

---

## [0.5.0] — 2026-06-09: Charges + Rate System

### Added
- rate_per_ton field to materials table
- wheel_count field to tickets table (via runMigrations)
- charges_type and charges_rate settings defaults
- Auto-fill rate from material master when material selected
- Auto-calculate charges when net weight changes
- Manual override capability for charges
- setField() function with smart recalculation logic

---

## [0.4.0] — 2026-06-09: Masters Screen

### Added
- MastersScreen.jsx
- Materials tab (add/edit/delete with rate_per_ton)
- Suppliers tab
- Receivers tab
- Vehicle history tab (auto-populated, view only)
- Standard tare display in vehicle list
- All master IPC handlers

---

## [0.3.0] — 2026-06-09: Weighing Screen + Pending Tickets

### Added
- WeighingScreen.jsx (full rebuild)
- Two-column layout: form (left) + summary/pending (right)
- Live weight display bar
- Capture GROSS button
- Capture TARE button
- Auto-calculate Net
- Auto-fill tare from vehicle standard_tare
- Save Pending (status=pending)
- Save & Complete (status=complete)
- Pending tickets panel with list
- Recent tickets list
- Open pending ticket to complete
- AutocompleteInput.jsx component
- vehicles:getByNo, vehicles:autoSave, tickets:getPending, tickets:getRecent IPC handlers

### Changed
- Ticket status field added to schema
- standard_tare added to vehicles
- runMigrations() implemented (production-safe schema evolution)

### Fixed
- Duplicate IPC handler registration (vehicles:autoSave, tickets:save)
- Database column not found error (status, standard_tare) — resolved via runMigrations + DB reset during dev

---

## [0.2.0] — 2026-06-08: SQLite Database

### Added
- src/database.js
- SQLite connection with WAL mode + foreign keys
- Tables: settings, vehicles, materials, suppliers, receivers, tickets, users
- Default settings seeded
- Default users seeded (superadmin, admin, operator)
- settings:getAll, settings:update IPC handlers
- IPC bridge working (React ↔ Electron ↔ SQLite)
- electron-log for structured logging

### Fixed
- better-sqlite3 module version mismatch (rebuilt for Electron via electron-rebuild)

---

## [0.1.0] — 2026-06-04: Project Setup

### Added
- Electron + React (Vite) project created at D:\weighbridge-app\
- src/main.js (Electron entry)
- src/preload.js (contextBridge)
- Root package.json with dev/build scripts
- cross-env fix for NODE_ENV on Windows
- Folder structure: modules/, components/, hooks/, utils/
- Module placeholders: WeighingScreen, MastersScreen, ReportsScreen, SettingsScreen
- App.jsx with sidebar navigation
- App runs on npm run dev ✅

---

## [1.0.0] — 2026-06-13: Production Build

### Added
- Ticket printing — full ticket (3 copies side by side) + data only mode
- TicketPrint.jsx with generateTicketHTML() and previewTicket()
- Settings → Printing tab
- License activation screen
- MongoDB-backed license system on server
- /api/license/reset endpoint
- Data migration tool — imports WeightSystem.mdb
- .exe installer via electron-builder (NSIS)
- Custom app icon (build/icon.ico)
- Diagnostics screen (Settings → Diagnostics)
- Help screen with Gujarati FAQ
- License Manager (superadmin only)
- Plan enforcement — Basic / Pro / Enterprise
- PlanGate component for feature locking
- usePlan hook + PlanProvider
- Change License Key in Settings → System
- Plan badge in sidebar
- Menu.setApplicationMenu(null) — removes default Electron menu
- Validation in WeighingScreen (gross/tare/vehicle/material)
- Charges synced from settings (not hardcoded)
- calcCharges() helper function
- wheel_count field in emptyForm and UI

### Fixed
- White screen on installed app — vite base: './' + app.getAppPath()
- Baud rate default changed to 2400
- chargesType undefined error in handleSave
- Negative charges when gross < tare (validation added)
- Settings not refreshing after save (loadAll() after save)
- Printer list loading moved into loadAll()
- MDBReader constructor error — fixed require pattern
- Duplicate IPC handler crashes

### Known Issues
- Serial port simulated (needs real implementation on client machine)
- EOD email not yet implemented
- Passwords stored as plain text
